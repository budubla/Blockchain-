//SPDX-License-Identifier: GPL-3.0
// SPDX-License-Identifier: MIT
pragma solidity ^0.5.0;
contract Test {
    uint num1 = 2;
    uint num2 = 4;
    function getResult(
 ) public view returns(
    uint product, uint sum
 ){
    product = num1 * num2;
    sum = num1 + num2;
 }

}