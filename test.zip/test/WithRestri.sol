// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;
contract WithdrawPattern {
    mapping ( address => uint ) public pendingWithdrawals;
    function deposit() public payable {
        pendingWithdrawals[msg.sender] += msg.value;
 }
 function withdraw() public {
    uint amount = pendingWithdrawals[msg.sender];
    require(amount > 0, "No balance");
    pendingWithdrawals[msg.sender] = 0;
    payable(msg.sender).transfer(amount);
 }
}